'use client';

import React, { useState } from 'react';
import ChessMasterAcademy from './ChessAcademy';
import ZombieTypingMaster from '@/lib/games/typing-zombie/ZombieTypingMaster';

type GameType = 'launcher' | 'chess' | 'zombie';

export default function Home() {
  const [currentGame, setCurrentGame] = useState<GameType>('launcher');

  if (currentGame === 'chess') {
    return (
      <div className="relative">
        <button
          onClick={() => setCurrentGame('launcher')}
          className="fixed top-4 left-4 z-50 px-4 py-2 bg-white/10 backdrop-blur-md rounded-lg text-white hover:bg-white/20 transition flex items-center gap-2"
        >
          ← Back to Games
        </button>
        <ChessMasterAcademy />
      </div>
    );
  }

  if (currentGame === 'zombie') {
    return (
      <div className="relative">
        <button
          onClick={() => setCurrentGame('launcher')}
          className="fixed top-4 left-4 z-50 px-4 py-2 bg-black/50 backdrop-blur-md rounded-lg text-white hover:bg-black/70 transition flex items-center gap-2 border border-red-500/30"
        >
          ← Back to Games
        </button>
        <ZombieTypingMaster />
      </div>
    );
  }

  // Game Launcher
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-slate-900 overflow-hidden">
      {/* Animated background */}
      <div className="fixed inset-0 pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-[600px] h-[600px] bg-purple-500/20 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-1/4 right-1/4 w-[500px] h-[500px] bg-blue-500/20 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '2s' }} />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-red-500/10 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '4s' }} />
        
        {/* Floating particles */}
        {[...Array(20)].map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 bg-white/30 rounded-full animate-float"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 5}s`,
              animationDuration: `${5 + Math.random() * 10}s`
            }}
          />
        ))}
      </div>

      <div className="relative z-10 min-h-screen flex flex-col items-center justify-center p-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-6xl md:text-7xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 via-red-500 to-purple-600 mb-4 animate-gradient-x">
            🎮 GAME ARCADE 🎮
          </h1>
          <p className="text-xl text-gray-300">Choose your adventure!</p>
        </div>

        {/* Game Cards */}
        <div className="grid md:grid-cols-2 gap-8 max-w-5xl w-full">
          {/* Chess Academy Card */}
          <button
            onClick={() => setCurrentGame('chess')}
            className="group relative bg-gradient-to-br from-amber-900/80 to-orange-900/80 backdrop-blur-sm rounded-3xl p-8 border-2 border-amber-500/30 hover:border-amber-400/60 transition-all duration-300 hover:scale-105 hover:shadow-2xl hover:shadow-amber-500/20 text-left overflow-hidden"
          >
            {/* Background glow effect */}
            <div className="absolute inset-0 bg-gradient-to-br from-amber-500/10 to-orange-500/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
            
            <div className="relative z-10">
              <div className="flex items-start justify-between mb-6">
                <span className="text-7xl group-hover:scale-110 transition-transform duration-300">♔</span>
                <span className="px-3 py-1 bg-green-500/20 text-green-300 rounded-full text-sm font-semibold">
                  Strategy
                </span>
              </div>
              
              <h2 className="text-3xl font-bold text-white mb-3 group-hover:text-amber-300 transition-colors">
                Chess Master Academy
              </h2>
              
              <p className="text-gray-300 mb-6 leading-relaxed">
                Complete chess learning platform with AI opponents (800-2500 ELO), 
                19+ lessons, tactics trainer, gambit academy, opening theory & more!
              </p>

              <div className="flex flex-wrap gap-2 mb-6">
                {['♟️ Play vs AI', '📚 19+ Lessons', '⚔️ Gambits', '🧩 Puzzles', '📖 Openings'].map(tag => (
                  <span key={tag} className="px-2 py-1 bg-black/30 rounded text-xs text-gray-300">
                    {tag}
                  </span>
                ))}
              </div>

              <div className="flex items-center gap-2 text-amber-400 font-semibold group-hover:text-amber-300">
                Play Now →
                <svg className="w-5 h-5 group-hover:translate-x-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                </svg>
              </div>
            </div>

            {/* Decorative corner element */}
            <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/10 rounded-full blur-2xl group-hover:bg-amber-500/20 transition-all duration-300" />
          </button>

          {/* Zombie Typing Master Card */}
          <button
            onClick={() => setCurrentGame('zombie')}
            className="group relative bg-gradient-to-br from-red-900/80 to-purple-900/80 backdrop-blur-sm rounded-3xl p-8 border-2 border-red-500/30 hover:border-red-400/60 transition-all duration-300 hover:scale-105 hover:shadow-2xl hover:shadow-red-500/20 text-left overflow-hidden"
          >
            {/* Background glow effect */}
            <div className="absolute inset-0 bg-gradient-to-br from-red-500/10 to-purple-500/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
            
            <div className="relative z-10">
              <div className="flex items-start justify-between mb-6">
                <span className="text-7xl group-hover:scale-110 transition-transform duration-300">🧟</span>
                <span className="px-3 py-1 bg-red-500/20 text-red-300 rounded-full text-sm font-semibold animate-pulse">
                  Action!
                </span>
              </div>
              
              <h2 className="text-3xl font-bold text-white mb-3 group-hover:text-red-300 transition-colors">
                Zombie Typing Master
              </h2>
              
              <p className="text-gray-300 mb-6 leading-relaxed">
                Type to kill zombies! Fast-paced typing game with smooth animations, 
                particle effects, power-ups, boss battles & combo system!
              </p>

              <div className="flex flex-wrap gap-2 mb-6">
                {['⌨️ Type to Kill', '💥 Effects', '⚡ Power-ups', '👹 Boss Fights', '🏆 High Scores'].map(tag => (
                  <span key={tag} className="px-2 py-1 bg-black/30 rounded text-xs text-gray-300">
                    {tag}
                  </span>
                ))}
              </div>

              <div className="flex items-center gap-2 text-red-400 font-semibold group-hover:text-red-300">
                Play Now →
                <svg className="w-5 h-5 group-hover:translate-x-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                </svg>
              </div>
            </div>

            {/* Decorative corner element */}
            <div className="absolute bottom-0 left-0 w-32 h-32 bg-red-500/10 rounded-full blur-2xl group-hover:bg-red-500/20 transition-all duration-300" />
          </button>
        </div>

        {/* Features section */}
        <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl w-full">
          <div className="bg-white/5 backdrop-blur-sm rounded-xl p-4 text-center border border-white/10">
            <div className="text-3xl mb-2">🆓</div>
            <p className="text-white font-semibold">100% Free</p>
            <p className="text-gray-400 text-sm">No ads or purchases</p>
          </div>
          <div className="bg-white/5 backdrop-blur-sm rounded-xl p-4 text-center border border-white/10">
            <div className="text-3xl mb-2">📱</div>
            <p className="text-white font-semibold">Responsive</p>
            <p className="text-gray-400 text-sm">Works on all devices</p>
          </div>
          <div className="bg-white/5 backdrop-blur-sm rounded-xl p-4 text-center border border-white/10">
            <div className="text-3xl mb-2">🎯</div>
            <p className="text-white font-semibold">Skill Building</p>
            <p className="text-gray-400 text-sm">Improve while playing</p>
          </div>
          <div className="bg-white/5 backdrop-blur-sm rounded-xl p-4 text-center border border-white/10">
            <div className="text-3xl mb-2">🔄</div>
            <p className="text-white font-semibold">Always Updated</p>
            <p className="text-gray-400 text-sm">New content regularly</p>
          </div>
        </div>

        {/* Footer */}
        <footer className="mt-16 text-center text-gray-500 text-sm">
          <p>🎮 Game Arcade - Free Educational Games</p>
          <p className="mt-1">Built with Next.js, React & ❤️</p>
        </footer>
      </div>

      {/* Custom styles for animations */}
      <style jsx global>{`
        @keyframes float {
          0%, 100% { transform: translateY(0) translateX(0); }
          25% { transform: translateY(-20px) translateX(10px); }
          50% { transform: translateY(-10px) translateX(-10px); }
          75% { transform: translateY(-30px) translateX(5px); }
        }
        .animate-float {
          animation: float linear infinite;
        }
        @keyframes gradient-x {
          0%, 100% { background-size: 200% 200%; background-position: left center; }
          50% { background-size: 200% 200%; background-position: right center; }
        }
        .animate-gradient-x {
          animation: gradient-x 3s ease infinite;
        }
      `}</style>
    </div>
  );
}
